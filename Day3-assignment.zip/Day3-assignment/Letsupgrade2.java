import java.util.Scanner;
public class Letsupgrade2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     float eng, phy, chem, math, comp; 
	     float total, average, percentage;
	    Scanner op=new Scanner(System.in);
	    /* Input marks of all five subjects */
	    System.out.println("***Enter marks of five subjects***");
	    System.out.print("Enter marks of English subjects:");
	    eng=op.nextFloat();
	    System.out.print("Enter marks of physics subjects:");
	    phy=op.nextFloat();
	    System.out.print("Enter marks of chemistry subjects:");
	    chem=op.nextFloat();
	    System.out.print("Enter marks of maths subjects:");
	    math=op.nextFloat();
	    System.out.print("Enter marks of computers subjects:");
	    comp=op.nextFloat();

	    /* Calculate total, average and percentage */
	    total = eng + phy + chem + math + comp;
	    average = (total / 5);
	    percentage = (total / 500) * 100;

	    /* Print all results */
	    System.out.println("Total marks ="+total);
	    
	    System.out.println("Percentage = "+percentage);
        
	    switch((int) percentage / 10){
	    case 9:
            System.out.println("Grade : A+");
            break;
        case 8:
        case 7:
            System.out.println("Grade : A");
            break;
        case 6:
            System.out.println("Grade : B");
            break;
        case 5:
            System.out.println("Grade : C");
            break;
        default:
            System.out.println("Grade : D");
            break;
	    	
   }
   }
}


