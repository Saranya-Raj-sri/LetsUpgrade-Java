import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.Calendar;
import java.text.DateFormat;
public class Letsupgrade3 {

	
		
	public static void main(String[] args) throws ParseException {
		
        String name;
        int day;
        int month;
        int year;
        float monthsalary,yrsalary;
		Scanner emp = new Scanner(System.in);
        System.out.println("***Employee details*** ");
        System.out.println("Enter the employee name");
        name = emp.next();
        System.out.println("Enter the date of birth:");
        day = emp.nextInt(Calendar.DATE);
        System.out.println("Enter the date of birth:");
        month = emp.nextInt(Calendar.MONTH);
        System.out.println("Enter the year of birth");
        year =  emp.nextInt(Calendar.YEAR);
        System.out.println("Enter the monthly salary:");
        monthsalary = emp.nextFloat();
        
        yrsalary=monthsalary*12;
        System.out.println("Annual salary is: "+yrsalary);
        
        if(yrsalary<=500000){
         System.out.println("Your tax is 20%");
         
        }
        else if(yrsalary<=400000){
        	System.out.println("Your tax is 15%");
        }
        else if(yrsalary<=300000){
        	System.out.println("Your tax is 10%");
        }
        else if(yrsalary<=200000){
        	System.out.println("Your tax is 5%");
        }
        else{
        	System.out.println("Invalid amount");
        }
	}

	}

